Battery and Energy Report 1.5
Modernes Windows Diagnose-Tool für Akku-, Energie- und Sleep-Analysen mit PowerShell und WPF, hauptsächlich für Laptops entwickelt.

Features
Live Akku-Überwachung
Akku-Gesundheitsanzeige mit Farbsystem
Battery Report
Energy Analyse Report
Sleep Study Report
Modern Standby Diagnostics (wenn unterstützt)
Sleep Blocker Erkennung
Hibernate Modus Ein/Aus
PowerCFG Dashboard
Technologien
PowerShell
WPF / XAML
Windows PowerCFG
CIM / WMI

Alle Reports werden gespeichert unter:
C:\Temp\EnergyReports

.zip Download enthält:
BatteryReport.exe - Administratorrechte sind nicht zwingend erforderlich!

Nutzung des Tools auf eigene Gefahr! 